# SBS Tiermaker – Neurosis
### Despliegue en Cloudflare Pages con KV Storage

---

## Estructura del proyecto

```
sbs-tiermaker/
├── index.html            ← La web completa
└── functions/
    └── votes.js          ← Worker function (API de votos)
```

No hay `package.json` ni dependencias. Cloudflare Pages ejecuta las
funciones de `/functions/` directamente como Workers.

---

## Pasos para desplegar

### 1. Subir el proyecto a GitHub

Crea un repositorio en GitHub y sube esta carpeta entera.
(También puedes usar GitLab o Bitbucket.)

### 2. Crear el proyecto en Cloudflare Pages

1. Ve a [dash.cloudflare.com](https://dash.cloudflare.com)
2. En el menú lateral: **Workers & Pages → Create application → Pages**
3. Conecta tu cuenta de GitHub y selecciona el repositorio
4. En la configuración de build:
   - **Framework preset:** None
   - **Build command:** *(dejar vacío)*
   - **Build output directory:** *(dejar vacío o poner `/`)*
5. Haz clic en **Save and Deploy**

### 3. Crear el KV Namespace

Los votos se guardan en **Cloudflare KV** (gratuito, hasta 100k escrituras/día).

1. En el dashboard de Cloudflare: **Workers & Pages → KV**
2. Haz clic en **Create a namespace**
3. Ponle el nombre que quieras, por ejemplo: `neurosis-votes`
4. Haz clic en **Add**

### 4. Vincular el KV al proyecto Pages

**Este paso es imprescindible** — sin él la función no puede guardar nada.

1. Ve a **Workers & Pages → tu proyecto → Settings → Functions**
2. Busca la sección **KV namespace bindings**
3. Haz clic en **Add binding**
4. Rellena así:
   - **Variable name:** `VOTES_KV`  ← exactamente este nombre, sin cambiarlo
   - **KV namespace:** selecciona el namespace que creaste antes
5. Haz clic en **Save**
6. Haz un nuevo deploy (o espera al próximo deploy automático)

### 5. ¡Listo!

Cloudflare te habrá dado una URL del tipo `tu-proyecto.pages.dev`.
Compártela con tus amigos y a votar. 🎸

---

## Cómo funciona

| Acción | Qué hace |
|--------|----------|
| Abrir la web | Carga todos los votos guardados desde KV |
| Entrar con tu nombre | Recupera tu voto anterior si existe |
| Arrastrar portadas | Solo se guarda localmente (en memoria) |
| Pulsar 💾 Guardar voto | Escribe en KV — persiste entre sesiones y dispositivos |
| Pulsar ⌀ Ver Media | Lee KV en tiempo real y calcula la media de todos los votos |

## Plan gratuito de Cloudflare

- **KV reads:** 100.000/día gratis
- **KV writes:** 1.000/día gratis
- **Pages:** ilimitado en el plan gratuito

Más que suficiente para un tiermaker entre amigos.
